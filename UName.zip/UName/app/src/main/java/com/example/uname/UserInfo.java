package com.example.uname;

public class UserInfo {

}
